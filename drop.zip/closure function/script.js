let boxes = document.querySelectorAll('.box');
image = document.querySelector('.image');
// let second_ul = document.querySelectorAll('.second');

// console.log(div)
boxes.forEach((box) => {
    box.addEventListener("dragover", (e) =>{
        e.preventDefault();
        box.classList.add("hovered");
    });

    box.addEventListener("dragleave", () => {
       box.classList.remove("hovered");
    });

    box.addEventListener("drop", () => {
       box.appendChild(image);
       box.classList.remove("hovered");
    });
});



 

// for(let item of div ){
// item.addEventListener('dragstart', function(){
//     this.classList.add('selected')
// })

// item.addEventListener('dragend', function(){
//     this.classList.remove('selected')
// })


// }

// second_ul.addEventListener('drop', function(){
//     e.preventDefault();
//     let selected = document.querySelector('.selected');

//     second_ul.appendChild(selected);

// })
